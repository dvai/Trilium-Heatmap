(async function () {
    const datas = {};
    let today = new Date();
    let tomorrow = new Date(today);
    tomorrow.setDate(today.getDate() + 1);
    let startDate = new Date(today.getFullYear() - 1, today.getMonth(), today.getDate());
    
    while (startDate <= tomorrow) {
        const formattedDate = startDate.toISOString().slice(0,10);
        const counts = await api.runOnBackend(async(formattedDate)=>{
            const editedNotes = api.sql.getColumn(`SELECT COUNT(*) AS data_count
                FROM notes
                WHERE utcDateModified LIKE '%${formattedDate}%'; `);
            return editedNotes;
        },[formattedDate]);
        
        if (counts != 0){
            datas[formattedDate] = counts[0];
        }
        startDate.setDate(startDate.getDate() + 1);
    }
    
    const str = JSON.stringify(datas);
    await api.runOnBackend(async(str)=>{
        const codeContent = "module.exports = function () {var arr="+str+";return arr;}";
        const note = api.getNoteWithLabel("heatmapDatas");
        note.setContent(codeContent);
    },[str]);
})();